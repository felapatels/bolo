import React from 'react';
import { Image, Pressable, StyleSheet, View } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withRepeat,
  withTiming,
  Easing,
} from 'react-native-reanimated';

/**
 * A round Bolo avatar that sits in the bottom-right corner of a screen and
 * triggers a chat navigation action when pressed.
 *
 * NOTE: The original Bolo app version uses expo-router, react-native-safe-area-context,
 * a custom PressableScale, and useColors(). This export replaces those with plain
 * React Native primitives and explicit props so the component is self-contained.
 *
 * Wire up `onPress` to navigate to your chat screen and pass `bottomOffset` to
 * position the FAB above your tab bar / navigation chrome.
 */
export function ParrotFAB({
  onPress,
  bottomOffset = 104,
  right = 20,
  backgroundColor = '#FFFFFF',
  borderColor = '#E5E7EB',
}: {
  /** Called when the FAB is tapped. Navigate to your chat screen here. */
  onPress: () => void;
  /** Distance from the bottom of the screen in px (default: 104, above a tab bar). */
  bottomOffset?: number;
  /** Distance from the right edge of the screen in px. */
  right?: number;
  /** Card / surface colour for the FAB bubble. */
  backgroundColor?: string;
  /** Border colour for the FAB bubble. */
  borderColor?: string;
}) {
  const reduceMotion = useReducedMotion();

  // Gentle idle float — makes Bolo feel alive even while not tapped.
  const floatVal = useSharedValue(0);
  React.useEffect(() => {
    if (reduceMotion) return;
    floatVal.value = withRepeat(
      withTiming(1, { duration: 2400, easing: Easing.inOut(Easing.sin) }),
      -1,
      true,
    );
  }, [reduceMotion, floatVal]);

  const floatStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: -5 * Math.sin(floatVal.value * Math.PI) }],
  }));

  return (
    <View
      style={[styles.container, { bottom: bottomOffset, right }]}
      pointerEvents="box-none"
    >
      <Animated.View style={floatStyle}>
        <Pressable
          onPress={onPress}
          accessibilityRole="button"
          accessibilityLabel="Chat with Bolo"
          style={[styles.fab, { backgroundColor, borderColor }]}
        >
          <Image
            source={require('./mascot/mascot-wave.png')}
            style={styles.fabImage}
            resizeMode="contain"
          />
        </Pressable>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    zIndex: 999,
    pointerEvents: 'box-none',
  },
  fab: {
    width: 62,
    height: 62,
    borderRadius: 31,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    // Subtle shadow so it floats above the screen content
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 6,
  },
  fabImage: {
    width: 52,
    height: 52,
  },
});
