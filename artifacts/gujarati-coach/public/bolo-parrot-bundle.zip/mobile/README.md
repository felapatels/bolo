# Bolo! Parrot Mascot — Mobile Component

Self-contained React Native (Expo) components for **Bolo the Parrot** with
Reanimated entrance and idle animations. Fully honours Expo Go's animation
limitations and the OS "Reduce Motion" setting.

## Requirements

```bash
# Install with expo install so the native modules are version-matched:
npx expo install react-native-reanimated expo-constants

# Peer deps (already present in any Expo project):
# react-native, react
```

## Asset setup

Copy the five PNGs from `mascot/` into the same folder as the component files
(the `require` paths are relative to the component file):

```
your-feature/
  Mascot.tsx
  TalkingMascot.tsx
  ParrotFAB.tsx
  entrance.ts
  mascot/
    mascot-wave.png
    mascot-cheer.png
    mascot-thumbsup.png
    mascot-thinking.png
    mascot-tryagain.png
```

Or adjust the `require('./mascot/...')` paths to match your project structure.

## Components

### `Mascot`

General-purpose mascot for any screen.

```tsx
import { Mascot } from './Mascot';

<Mascot pose="wave" />
<Mascot pose="cheer" size={160} motion="bounce" />
<Mascot pose="thinking" motion="sway" entering={false} />
```

| Prop       | Type                                                       | Default    | Description                               |
|------------|------------------------------------------------------------|------------|-------------------------------------------|
| `pose`     | `"wave" \| "cheer" \| "thumbsup" \| "thinking" \| "tryagain"` | required   | Which PNG to render                   |
| `size`     | `number`                                                   | `96`       | Width & height in logical pixels          |
| `motion`   | `"none" \| "float" \| "bounce" \| "sway"`                 | `"float"`  | Idle loop animation                       |
| `entering` | `boolean`                                                  | `true`     | Play spring pop entrance on mount/pose change |
| `style`    | `StyleProp<ImageStyle>`                                    | —          | Extra styles forwarded to the Image       |

### `TalkingMascot`

Extended mascot for chat / conversation screens with four animated states.

```tsx
import { TalkingMascot } from './TalkingMascot';

<TalkingMascot mode="idle" />
<TalkingMascot mode="listening" primaryColor="#6366F1" />
<TalkingMascot mode="talking" size={200} />
```

| Prop               | Type                                               | Default       | Description                        |
|--------------------|----------------------------------------------------|---------------|------------------------------------|
| `mode`             | `"idle" \| "listening" \| "talking" \| "thinking"` | required      | Animated state                     |
| `size`             | `number`                                           | `160`         | Width & height in logical pixels   |
| `primaryColor`     | `string`                                           | `"#6366F1"`   | Colour for pulse ring & sound bars |
| `destructiveColor` | `string`                                           | `"#EF4444"`   | Colour for the mic dot             |

### `ParrotFAB`

A floating action button that sits in a corner and opens a chat screen.

```tsx
import { ParrotFAB } from './ParrotFAB';

<ParrotFAB
  onPress={() => navigation.navigate('Chat')}
  bottomOffset={96 + insets.bottom}
/>
```

| Prop               | Type         | Default      | Description                                     |
|--------------------|--------------|--------------|--------------------------------------------------|
| `onPress`          | `() => void` | required     | Callback when FAB is pressed                    |
| `bottomOffset`     | `number`     | `104`        | Distance from bottom of screen (px)             |
| `right`            | `number`     | `20`         | Distance from right edge (px)                   |
| `backgroundColor`  | `string`     | `"#FFFFFF"`  | FAB bubble background                           |
| `borderColor`      | `string`     | `"#E5E7EB"`  | FAB bubble border                               |

## Poses

| Pose        | When to use                                              |
|-------------|----------------------------------------------------------|
| `wave`      | Greetings, home screen, empty states, welcome back       |
| `cheer`     | Wins — lesson complete, streak milestone, badge earned   |
| `thumbsup`  | Good attempt — correct answer, decent score              |
| `thinking`  | Loading / listening / hints                              |
| `tryagain`  | Gentle "try again" after a miss                          |

## Notes

- **Expo Go safety**: `entrance.ts` automatically disables entrance animations
  in Expo Go to prevent views being stuck at `opacity: 0`. Development and
  production builds get the full spring pop.
- **Reduce Motion**: all animations (entrance, idle, sound bars, pulse ring)
  gracefully collapse when the OS "Reduce Motion" setting is on.

---

## Making Bolo talk

`useBoloChat.ts` is a React hook that wires `TalkingMascot`'s `mode` prop to
Bolo's live language-learning AI. **No `OPENAI_API_KEY` required** — the API
key lives on Bolo's server; your app just calls it.

### Minimal example

```tsx
import { useRef } from "react";
import { Audio } from "expo-av";
import { TalkingMascot } from "./TalkingMascot";
import { useBoloChat, Turn } from "./useBoloChat";

export function ChatScreen() {
  const { mode, setMode, sendMessage } = useBoloChat({ languageCode: "gu" /* Gujarati */ });
  const history = useRef<Turn[]>([]);

  async function handleSend(text: string) {
    const { reply, audioBase64 } = await sendMessage(text, history.current);

    history.current = [
      ...history.current,
      { role: "learner", content: text },
      { role: "parrot", content: reply },
    ];

    // Play Bolo's audio reply, then return to idle
    const { sound } = await Audio.Sound.createAsync(
      { uri: `data:audio/mp3;base64,${audioBase64}` },
      { shouldPlay: true },
    );
    sound.setOnPlaybackStatusUpdate((status) => {
      if (status.isLoaded && status.didJustFinish) {
        setMode("idle");
        sound.unloadAsync();
      }
    });
  }

  return <TalkingMascot mode={mode} size={160} />;
}
```

### API reference

```ts
import { useBoloChat, defaultApiBase, Turn, ChatMode } from "./useBoloChat";

const {
  mode,             // "idle" | "listening" | "thinking" | "talking"
  setMode,          // manually drive mode (e.g. setMode("idle") after audio ends)
  sendMessage,      // (text, history) → { reply, audioBase64 }
  transcribeAudio,  // (audioBase64) → transcript string
  synthesizeSpeech, // (text) → base64 MP3 string
} = useBoloChat({
  languageCode: "hi",          // required — BCP-47 code, e.g. "gu", "hi", "ta"
  apiBase: defaultApiBase,     // optional — override to point at a local server
});
```

### `Turn` type

```ts
interface Turn {
  role: "learner" | "parrot";
  content: string;
}
```

### Mode lifecycle

`sendMessage` drives `mode` automatically:

```
idle  ──sendMessage()──▶  thinking  ──reply ready──▶  talking
                                                          │
                                               setMode("idle") after audio ends
```

Set `mode` to `"listening"` yourself while the learner is recording audio, then
call `transcribeAudio` on the result and pass the transcript to `sendMessage`.
