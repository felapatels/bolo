/**
 * useBoloChat.ts — React hook that wires Bolo's chat, TTS, and STT endpoints
 * to the TalkingMascot component's `mode` prop.
 *
 * Uses only `useState`, `useCallback`, and the global `fetch` — no
 * platform-specific imports — so it works in Expo and plain React Native.
 *
 * @example
 * ```tsx
 * import { useBoloChat } from "./useBoloChat";
 * import { TalkingMascot } from "./TalkingMascot";
 *
 * function ChatScreen() {
 *   const { mode, setMode, sendMessage, transcribeAudio, synthesizeSpeech } =
 *     useBoloChat({ languageCode: "gu" });
 *
 *   return <TalkingMascot mode={mode} />;
 * }
 * ```
 */

import { useState, useCallback } from "react";

// The canonical production URL for Bolo's API.
// Override via the `apiBase` option when pointing at a local dev server.
export const defaultApiBase = "https://bolo-india.app/api";

// A single prior turn of conversation.
export interface Turn {
  role: "learner" | "parrot";
  content: string;
}

/**
 * The animated state of the TalkingMascot.
 *
 * | mode       | meaning                                                |
 * |------------|--------------------------------------------------------|
 * | idle       | Bolo is waiting — gentle floating animation            |
 * | listening  | Learner is speaking — mic ring pulses                  |
 * | thinking   | Waiting for the server reply — slow oscillation        |
 * | talking    | Bolo is playing his audio reply — beak-bob + sound bars|
 */
export type ChatMode = "idle" | "listening" | "thinking" | "talking";

/**
 * Create a Bolo chat hook pre-configured for a language.
 *
 * @param apiBase  Override the API base URL (default: Bolo's production API).
 * @param languageCode  BCP-47 / ISO 639-1 code for the language to practice,
 *                      e.g. "gu" for Gujarati, "hi" for Hindi.
 */
export function useBoloChat({
  apiBase = defaultApiBase,
  languageCode,
}: {
  apiBase?: string;
  languageCode: string;
}) {
  const [mode, setMode] = useState<ChatMode>("idle");
  const base = apiBase.replace(/\/$/, "");

  /**
   * Synthesize text to speech via Bolo's TTS endpoint.
   * Returns a base64-encoded MP3 string.
   */
  const synthesizeSpeech = useCallback(
    async (text: string): Promise<string> => {
      const res = await fetch(`${base}/openai/tts`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      });
      if (!res.ok) {
        throw new Error(`TTS failed: HTTP ${res.status}`);
      }
      const data = (await res.json()) as { audioBase64: string };
      return data.audioBase64;
    },
    [base],
  );

  /**
   * Transcribe a base64-encoded audio clip (WAV or MP3) to text.
   * Call this after recording the learner's voice before passing the
   * transcript to sendMessage or displaying it in the UI.
   */
  const transcribeAudio = useCallback(
    async (audioBase64: string): Promise<string> => {
      const res = await fetch(`${base}/openai/pronunciation`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ audioBase64 }),
      });
      if (!res.ok) {
        throw new Error(`Transcription failed: HTTP ${res.status}`);
      }
      const data = (await res.json()) as { transcript: string };
      return data.transcript ?? "";
    },
    [base],
  );

  /**
   * Send a typed text message to Bolo and receive his reply.
   *
   * Drives `mode` through the full lifecycle automatically:
   *   idle → thinking → talking → (caller resets to idle after audio finishes)
   *
   * Internally the text is synthesized to audio so the server can run its
   * full transcribe → reply → synthesize pipeline.  The caller gets back
   * Bolo's reply text and a base64-encoded MP3 ready to play.
   *
   * Call `setMode("idle")` once audio playback completes.
   */
  const sendMessage = useCallback(
    async (
      text: string,
      history: Turn[],
    ): Promise<{ reply: string; audioBase64: string }> => {
      setMode("thinking");
      try {
        // The /openai/chat endpoint is audio-in / audio-out. Synthesize the
        // caller's text to audio so the server receives a valid audio clip.
        const inputAudio = await synthesizeSpeech(text);

        // Map the bundle's Turn.content field to the server's `text` field.
        const serverHistory = history.map((t) => ({
          role: t.role,
          text: t.content,
        }));

        const res = await fetch(`${base}/openai/chat`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            languageCode,
            audioBase64: inputAudio,
            history: serverHistory,
          }),
        });
        if (!res.ok) {
          throw new Error(`Chat failed: HTTP ${res.status}`);
        }
        const data = (await res.json()) as {
          replyText: string;
          replyAudioBase64: string;
        };

        // Transition to talking; the caller should call setMode("idle") once
        // audio playback ends.
        setMode("talking");
        return { reply: data.replyText, audioBase64: data.replyAudioBase64 };
      } catch (err) {
        setMode("idle");
        throw err;
      }
    },
    [base, languageCode, synthesizeSpeech],
  );

  return { mode, setMode, sendMessage, transcribeAudio, synthesizeSpeech };
}
