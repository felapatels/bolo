# Bolo! Parrot Mascot Bundle

This archive contains the **Bolo the Parrot** mascot component in two flavours:

| Folder    | Stack                          | Entry points                                                                           |
|-----------|--------------------------------|----------------------------------------------------------------------------------------|
| `web/`    | React + Framer Motion          | `mascot.tsx`, `motion-helpers.ts`, `bolo-chat.ts`                                      |
| `mobile/` | React Native + Expo Reanimated | `Mascot.tsx`, `TalkingMascot.tsx`, `ParrotFAB.tsx`, `entrance.ts`, `useBoloChat.ts`    |

Both folders include the five mascot PNGs under `mascot/` and a `README.md`
with full prop references, asset setup instructions, and usage examples.

## Quick start

1. Pick the folder that matches your stack (`web/` or `mobile/`).
2. Follow the `README.md` inside that folder.
3. Copy the `mascot/` PNGs to the right location in your project.
4. Install the listed npm dependencies and import the component.

## Making Bolo talk — no API key needed

Both folders include a pre-wired chat client that connects to Bolo's deployed
AI backend. **Your app does not need an `OPENAI_API_KEY`** — Bolo's API handles
it. The only thing you need is a network-reachable deployment of the Bolo API,
and the default already points at the live production app.

| File                 | Stack           | What it does                                                        |
|----------------------|-----------------|---------------------------------------------------------------------|
| `web/bolo-chat.ts`   | Any (fetch)     | `createBoloChat()` — plain TypeScript, no React dependency          |
| `mobile/useBoloChat.ts` | React / RN   | `useBoloChat()` — React hook that also drives `TalkingMascot` mode  |

Both modules call three endpoints on `defaultApiBase` (`https://bolo-india.app/api`):

| Method / export        | Endpoint called              | Purpose                              |
|------------------------|------------------------------|--------------------------------------|
| `sendMessage`          | `POST /openai/chat`          | Full turn: text → Bolo reply + audio |
| `transcribeAudio`      | `POST /openai/pronunciation` | Convert audio clip to text           |
| `synthesizeSpeech`     | `POST /openai/tts`           | Convert text to base64 MP3 audio     |

Pass `apiBase` to either module to point at a local dev server during
development:

```ts
// Web
const bolo = createBoloChat({ languageCode: "gu", apiBase: "http://localhost:3000/api" });

// Mobile
const { mode, sendMessage } = useBoloChat({ languageCode: "gu", apiBase: "http://localhost:3000/api" });
```

## Image assets

The five PNGs ship in both `web/mascot/` and `mobile/mascot/` for convenience
— they are identical files. You only need one copy in your project.

| File                   | Mood / when to use                               |
|------------------------|--------------------------------------------------|
| `mascot-wave.png`      | Greetings, home, empty states, welcome back      |
| `mascot-cheer.png`     | Wins — lesson complete, streak, badge            |
| `mascot-thumbsup.png`  | Good attempt — correct answer, decent score      |
| `mascot-thinking.png`  | Loading / listening / hints                      |
| `mascot-tryagain.png`  | Gentle "try again" after a miss                  |
