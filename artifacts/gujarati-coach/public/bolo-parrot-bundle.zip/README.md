# Bolo! Parrot Mascot Bundle

This archive contains the **Bolo the Parrot** mascot component in two flavours:

| Folder    | Stack                          | Entry points                                                            |
|-----------|--------------------------------|-------------------------------------------------------------------------|
| `web/`    | React + Framer Motion          | `mascot.tsx`, `motion-helpers.ts`                                       |
| `mobile/` | React Native + Expo Reanimated | `Mascot.tsx`, `TalkingMascot.tsx`, `ParrotFAB.tsx`, `entrance.ts`       |

Both folders include the five mascot PNGs under `mascot/` and a `README.md`
with full prop references, asset setup instructions, and usage examples.

## Quick start

1. Pick the folder that matches your stack (`web/` or `mobile/`).
2. Follow the `README.md` inside that folder.
3. Copy the `mascot/` PNGs to the right location in your project.
4. Install the listed npm dependencies and import the component.

## Image assets

The five PNGs ship in both `web/mascot/` and `mobile/mascot/` for convenience
— they are identical files. You only need one copy in your project.

| File                   | Mood / when to use                               |
|------------------------|--------------------------------------------------|
| `mascot-wave.png`      | Greetings, home, empty states, welcome back      |
| `mascot-cheer.png`     | Wins — lesson complete, streak, badge            |
| `mascot-thumbsup.png`  | Good attempt — correct answer, decent score      |
| `mascot-thinking.png`  | Loading / listening / hints                      |
| `mascot-tryagain.png`  | Gentle "try again" after a miss                  |
