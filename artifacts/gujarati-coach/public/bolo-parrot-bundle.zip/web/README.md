# Bolo! Parrot Mascot — Web Component

A self-contained React component for **Bolo the Parrot** with Framer Motion
entrance and idle animations. Fully honours the OS "Reduce Motion" setting.

## Requirements

```bash
npm install framer-motion
# or
pnpm add framer-motion
```

No other runtime dependencies. TypeScript ≥ 5.0 and React ≥ 18 are expected.

## Asset setup

Copy the five PNGs from `mascot/` into your project's public folder:

```
your-project/
  public/
    mascot/
      mascot-wave.png
      mascot-cheer.png
      mascot-thumbsup.png
      mascot-thinking.png
      mascot-tryagain.png
```

Copy `mascot.tsx` and `motion-helpers.ts` anywhere in your `src/` tree (they
import each other, so keep them in the same folder).

## Usage

```tsx
import { Mascot } from "./mascot";

// Basic — 96 px, gently floating
<Mascot pose="wave" />

// Larger, celebratory hop
<Mascot pose="cheer" size={160} idle="cheer" />

// Static, fills parent container
<Mascot pose="thumbsup" fill idle="none" />

// Custom image base path (e.g. when using Vite BASE_URL)
<Mascot pose="thinking" basePath={import.meta.env.BASE_URL + "mascot/"} />
```

## Props

| Prop        | Type                                                              | Default      | Description                                       |
|-------------|-------------------------------------------------------------------|--------------|---------------------------------------------------|
| `pose`      | `"wave" \| "cheer" \| "thumbsup" \| "thinking" \| "tryagain"`    | (required)   | Which mascot image to show                        |
| `size`      | `number`                                                          | `96`         | Width & height in px (ignored when `fill` is true)|
| `idle`      | `"float" \| "cheer" \| "none"`                                    | `"float"`    | Idle loop animation after entrance                |
| `className` | `string`                                                          | —            | Extra CSS classes on the wrapper div              |
| `fill`      | `boolean`                                                         | `false`      | Stretch to 100% of parent container               |
| `basePath`  | `string`                                                          | `"/mascot/"` | URL prefix for the PNG files (trailing slash)     |

## Poses

| Pose        | When to use                                              |
|-------------|----------------------------------------------------------|
| `wave`      | Greetings, home screen, empty states, welcome back       |
| `cheer`     | Wins — lesson complete, streak milestone, badge earned   |
| `thumbsup`  | Good attempt — correct answer, decent score              |
| `thinking`  | Loading / listening / hints                              |
| `tryagain`  | Gentle "try again" after a miss                          |
