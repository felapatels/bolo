# Bolo! Parrot Mascot — Web Component

A self-contained React component for **Bolo the Parrot** with Framer Motion
entrance and idle animations. Fully honours the OS "Reduce Motion" setting.

## Requirements

```bash
npm install framer-motion
# or
pnpm add framer-motion
```

No other runtime dependencies. TypeScript ≥ 5.0 and React ≥ 18 are expected.

## Asset setup

Copy the five PNGs from `mascot/` into your project's public folder:

```
your-project/
  public/
    mascot/
      mascot-wave.png
      mascot-cheer.png
      mascot-thumbsup.png
      mascot-thinking.png
      mascot-tryagain.png
```

Copy `mascot.tsx` and `motion-helpers.ts` anywhere in your `src/` tree (they
import each other, so keep them in the same folder).

## Usage

```tsx
import { Mascot } from "./mascot";

// Basic — 96 px, gently floating
<Mascot pose="wave" />

// Larger, celebratory hop
<Mascot pose="cheer" size={160} idle="cheer" />

// Static, fills parent container
<Mascot pose="thumbsup" fill idle="none" />

// Custom image base path (e.g. when using Vite BASE_URL)
<Mascot pose="thinking" basePath={import.meta.env.BASE_URL + "mascot/"} />
```

## Props

| Prop        | Type                                                              | Default      | Description                                       |
|-------------|-------------------------------------------------------------------|--------------|---------------------------------------------------|
| `pose`      | `"wave" \| "cheer" \| "thumbsup" \| "thinking" \| "tryagain"`    | (required)   | Which mascot image to show                        |
| `size`      | `number`                                                          | `96`         | Width & height in px (ignored when `fill` is true)|
| `idle`      | `"float" \| "cheer" \| "none"`                                    | `"float"`    | Idle loop animation after entrance                |
| `className` | `string`                                                          | —            | Extra CSS classes on the wrapper div              |
| `fill`      | `boolean`                                                         | `false`      | Stretch to 100% of parent container               |
| `basePath`  | `string`                                                          | `"/mascot/"` | URL prefix for the PNG files (trailing slash)     |

## Poses

| Pose        | When to use                                              |
|-------------|----------------------------------------------------------|
| `wave`      | Greetings, home screen, empty states, welcome back       |
| `cheer`     | Wins — lesson complete, streak milestone, badge earned   |
| `thumbsup`  | Good attempt — correct answer, decent score              |
| `thinking`  | Loading / listening / hints                              |
| `tryagain`  | Gentle "try again" after a miss                          |

---

## Making Bolo talk

`bolo-chat.ts` is a zero-dependency TypeScript module that wires `Mascot` (or
any UI) to Bolo's live language-learning AI. **No `OPENAI_API_KEY` required** —
the API key lives on Bolo's server; your app just calls it.

### Minimal example

```tsx
import { useState } from "react";
import { Mascot } from "./mascot";
import { createBoloChat, Turn } from "./bolo-chat";

// Point at Bolo's production API (the default) or a local dev server.
const bolo = createBoloChat({ languageCode: "gu" /* Gujarati */ });

export function ChatWidget() {
  const [mode, setMode] = useState<"idle" | "thinking" | "talking">("idle");
  const [history, setHistory] = useState<Turn[]>([]);

  async function handleSend(text: string) {
    setMode("thinking");
    const { reply, audioBase64 } = await bolo.sendMessage(text, history);

    setHistory((h) => [
      ...h,
      { role: "learner", content: text },
      { role: "parrot", content: reply },
    ]);

    // Play Bolo's audio reply
    const audio = new Audio(`data:audio/mp3;base64,${audioBase64}`);
    setMode("talking");
    audio.onended = () => setMode("idle");
    audio.play();
  }

  return (
    <div>
      <Mascot pose={mode === "talking" ? "wave" : "thinking"} size={160} />
      <button onClick={() => handleSend("Hello Bolo!")} disabled={mode !== "idle"}>
        Say hello
      </button>
    </div>
  );
}
```

### API reference

```ts
import { createBoloChat, defaultApiBase, Turn } from "./bolo-chat";

// Create a chat handle for a specific language
const bolo = createBoloChat({
  languageCode: "hi",           // required — BCP-47 code, e.g. "gu", "hi", "ta"
  apiBase: defaultApiBase,      // optional — override to point at a local server
});

// Send a typed message; returns Bolo's reply text + base64 MP3 audio
const { reply, audioBase64 } = await bolo.sendMessage(text, history);

// Transcribe a base64 audio clip (WAV or MP3) to text
const transcript = await bolo.transcribeAudio(audioBase64);

// Synthesize text to speech; returns base64 MP3
const audio = await bolo.synthesizeSpeech(text);
```

### `Turn` type

```ts
interface Turn {
  role: "learner" | "parrot";
  content: string;
}
```
