import { motion, useReducedMotion } from "framer-motion";
import { mascotEntrance, floatIdle } from "./motion-helpers";

// Bolo the Parrot — the friendly face of the app. Each pose maps to a mood so
// screens can show the right reaction for the moment.
// Place the 5 PNG files in <public>/mascot/ (or override basePath).
export type MascotPose = "wave" | "cheer" | "thumbsup" | "thinking" | "tryagain";

const POSE_SRC: Record<MascotPose, string> = {
  wave: "mascot-wave.png",
  cheer: "mascot-cheer.png",
  thumbsup: "mascot-thumbsup.png",
  thinking: "mascot-thinking.png",
  tryagain: "mascot-tryagain.png",
};

// How the mascot idles once it's on screen. "float" gently bobs (default),
// "cheer" adds a springy celebratory hop, "none" stays put.
type IdleMotion = "float" | "cheer" | "none";

export function Mascot({
  pose,
  size = 96,
  idle = "float",
  className,
  fill = false,
  basePath = "/mascot/",
}: {
  pose: MascotPose;
  size?: number;
  idle?: IdleMotion;
  className?: string;
  /**
   * When true, the mascot stretches to fill its parent container (width/height
   * 100%). Use this when you want the parrot to scale with a flex/grid cell.
   * The `size` prop is ignored when `fill` is true.
   */
  fill?: boolean;
  /**
   * Base path to the mascot images directory (with trailing slash).
   * Defaults to "/mascot/" — copy the 5 PNGs to <public>/mascot/ to match.
   * Override if your project uses a different public path (e.g. Vite BASE_URL).
   */
  basePath?: string;
}) {
  const reduceMotion = useReducedMotion();
  const src = basePath + POSE_SRC[pose];

  // Shared motion primitives: the springy entrance + gentle idle bob.
  // Both collapse to a still frame under reduced motion.
  const entrance = mascotEntrance(reduceMotion);
  const bob = idle === "none" ? undefined : floatIdle(reduceMotion, idle);

  return (
    <motion.div
      key={pose}
      {...entrance}
      className={`relative select-none${className ? " " + className : ""}`}
      style={fill ? { width: "100%", height: "100%" } : { width: size, height: size }}
      aria-hidden="true"
    >
      <motion.img
        src={src}
        alt=""
        draggable={false}
        style={{ width: "100%", height: "100%", objectFit: "contain" }}
        animate={bob?.animate}
        transition={bob?.transition}
      />
    </motion.div>
  );
}
