/**
 * bolo-chat.ts — Zero-dependency TypeScript chat client for Bolo the Parrot.
 *
 * Wraps Bolo's /api/openai/* endpoints so consumers need no OpenAI API key.
 * Works in any environment with a global `fetch` (browser, Node ≥ 18, Deno,
 * React Native via the built-in polyfill).
 *
 * @example
 * ```ts
 * import { createBoloChat } from "./bolo-chat";
 *
 * const bolo = createBoloChat({ languageCode: "gu" });
 * const { reply, audioBase64 } = await bolo.sendMessage("Hello!", []);
 * ```
 */

// The canonical production URL for Bolo's API.
// Override via the `apiBase` option when pointing at a local dev server.
export const defaultApiBase = "https://bolo-india.app/api";

// A single prior turn of conversation.
export interface Turn {
  role: "learner" | "parrot";
  content: string;
}

// The handle returned by createBoloChat.
export interface BoloChat {
  /**
   * Send a typed text message to Bolo and receive his reply.
   *
   * Internally the text is synthesized to audio so the server can run its
   * full transcribe → reply → synthesize pipeline.  The caller gets back
   * Bolo's reply text and the base64-encoded MP3 audio ready to play.
   */
  sendMessage(
    text: string,
    history: Turn[],
  ): Promise<{ reply: string; audioBase64: string }>;

  /**
   * Transcribe a base64-encoded audio clip (WAV or MP3) to text.
   * Useful when the learner has recorded their own voice before calling sendMessage.
   */
  transcribeAudio(audioBase64: string): Promise<string>;

  /**
   * Synthesize text to speech via Bolo's TTS endpoint.
   * Returns a base64-encoded MP3 string.
   */
  synthesizeSpeech(text: string): Promise<string>;
}

/**
 * Create a Bolo chat handle pre-configured for a language.
 *
 * @param apiBase  Override the API base URL (default: Bolo's production API).
 * @param languageCode  BCP-47 / ISO 639-1 code for the language to practice,
 *                      e.g. "gu" for Gujarati, "hi" for Hindi.
 */
export function createBoloChat({
  apiBase = defaultApiBase,
  languageCode,
}: {
  apiBase?: string;
  languageCode: string;
}): BoloChat {
  const base = apiBase.replace(/\/$/, "");

  async function synthesizeSpeech(text: string): Promise<string> {
    const res = await fetch(`${base}/openai/tts`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    if (!res.ok) {
      throw new Error(`TTS failed: HTTP ${res.status}`);
    }
    const data = (await res.json()) as { audioBase64: string };
    return data.audioBase64;
  }

  async function transcribeAudio(audioBase64: string): Promise<string> {
    const res = await fetch(`${base}/openai/pronunciation`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ audioBase64 }),
    });
    if (!res.ok) {
      throw new Error(`Transcription failed: HTTP ${res.status}`);
    }
    const data = (await res.json()) as { transcript: string };
    return data.transcript ?? "";
  }

  async function sendMessage(
    text: string,
    history: Turn[],
  ): Promise<{ reply: string; audioBase64: string }> {
    // The /openai/chat endpoint is audio-in / audio-out: it transcribes the
    // learner's spoken audio, generates an in-character reply, and synthesizes
    // it.  For a typed-text caller we synthesize the text to audio first so
    // the server receives a valid audio clip.
    const inputAudio = await synthesizeSpeech(text);

    // Map the bundle's Turn.content field to the server's `text` field.
    const serverHistory = history.map((t) => ({
      role: t.role,
      text: t.content,
    }));

    const res = await fetch(`${base}/openai/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        languageCode,
        audioBase64: inputAudio,
        history: serverHistory,
      }),
    });
    if (!res.ok) {
      throw new Error(`Chat failed: HTTP ${res.status}`);
    }
    const data = (await res.json()) as {
      replyText: string;
      replyAudioBase64: string;
    };
    return { reply: data.replyText, audioBase64: data.replyAudioBase64 };
  }

  return { sendMessage, transcribeAudio, synthesizeSpeech };
}
