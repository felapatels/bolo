import type { Transition, MotionProps } from "framer-motion";

/**
 * A springy "pop + settle" entrance, matching the mascot's arrival in the
 * Bolo launch video. Pass the result of `useReducedMotion()` so it can
 * collapse to a plain fade when motion is reduced.
 */
export function mascotEntrance(reduceMotion: boolean | null): MotionProps {
  if (reduceMotion) {
    return {
      initial: { opacity: 0 },
      animate: { opacity: 1 },
      transition: { duration: 0.001 },
    };
  }
  return {
    initial: { opacity: 0, scale: 0.55, y: 12 },
    animate: { opacity: 1, scale: 1, y: 0 },
    transition: { type: "spring", stiffness: 260, damping: 18 },
  };
}

/**
 * A gentle, looping bob. "cheer" adds a springier celebratory hop. Returns
 * `undefined` when motion is reduced so the element simply stays put.
 */
export function floatIdle(
  reduceMotion: boolean | null,
  variant: "float" | "cheer" = "float",
): { animate: MotionProps["animate"]; transition: Transition } | undefined {
  if (reduceMotion) return undefined;
  if (variant === "cheer") {
    return {
      animate: { y: [0, -10, 0], rotate: [0, -3, 3, 0] },
      transition: { duration: 1.6, repeat: Infinity, ease: "easeInOut" },
    };
  }
  return {
    animate: { y: [0, -6, 0], rotate: [0, -1.5, 1.5, 0] },
    transition: { duration: 4, repeat: Infinity, ease: "easeInOut" },
  };
}
